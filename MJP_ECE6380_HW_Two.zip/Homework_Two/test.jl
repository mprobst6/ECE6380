ref = string("reflection coeff = ",1)
open("test.txt","w") do io
    wri